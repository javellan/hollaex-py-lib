from setuptools import setup, find_packages


setup(
    name='hollaex-py-lib',
    version='1',
    license='MIT',
    author="Mahdi",
    author_email='mahdi@hollaex.com',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='https://github.com/hollaex/hollaex-py-lib',
    keywords='Hollaex',
    install_requires=[
          
      ],

)
